<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Telegram\Bot\Laravel\Facades\Telegram;

class TelegramController extends Controller
{
    public function webhook(Request $request)
    {

        $telegram = new Telegram(env('TELEGRAM_BOT_TOKEN'));

        // Parse incoming update
        $update = $telegram->getWebhookUpdate();

        // Handle incoming messages or commands
        if ($update->getMessage()) {
            $message = $update->getMessage();
            $chatId = $message->getChat()->getId();
            $text = $message->getText();

            // Handle different commands or messages
            if ($text === '/start') {
                $response = 'Welcome to your Telegram bot!';
            } else {
                $response = 'You said: ' . $text;
            }

            // Send a response back to the user
            $telegram->sendMessage([
                'chat_id' => $chatId,
                'text' => $response,
            ]);
        }

        return response()->json(['status' => 'ok']);
    }
}
