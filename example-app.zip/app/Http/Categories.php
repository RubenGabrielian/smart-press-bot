<?php

namespace App\Http;

class ConstantCategories {

    const RUBEN = 'aziz';
    public function getEnglishCategories () {
        return self::RUBEN;
    }
}
